// Modules
const express = require('express')
const { send } = require('process')
const port = 3000
const app = express()

// Setting Parameters for Express Server on the VM
app.get('/most_experience', (request, response) => {
    var http = require('http');
    var options = {
        host: '13.72.222.194', 
        port: '3000',  
        path: '/skill?skill_name=' + request.query.skill_name, 
        method: 'GET', 
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Content-Length': 0
        }
    }
 
// Calling the Express Server on VM
var req = http.request(options, function(res) {
    var msg = []; 
    res.setEncoding('utf8');
    res.on('data', function(chunk) {
        msg.push(chunk) 
    }).on('end', function() {
        msg2 = JSON.parse(String(msg)) 
        for(i=0; i<msg2.length; i++) { 
            obj = JSON.parse(msg2[i]) 
            if(i !=0)
            { 
                if(obj.experience > obj.experience)
                { 
                    obj1 =obj;
                }
                else
                {
                    obj1 = obj;
                }
            }
            else
            obj1 =JSON.parse(msg2[i])
        }
        response.write('Name = ' + obj1.name + ', Skill = ' + obj1.skill +', Experience = ' + 
        obj1.experience + ', Hourly_rate = ' + obj1.hourly_rate + '\n')
        response.end();
    });
})
req.end();
})

// Setting Parameters for Express Server on the VM [Lowest Hourly Rate] 
app.get('/lowest_rate', (request, response) => {
    var http = require('http'); 
    var options = {
        host: '13.77.222.194', 
        port: '3000', 
        path: '/skill?skill_name=' + request.query.skill_name, 
        method: 'GET', 
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Content-Length': 0
        }
    }
    console.log(options.path)
    
    // Calling the Express Server on VM
    var req = http.request(options, function(res) {
        var msg = []; 
        res.setEncoding('utf8');
        res.on('data', function(chunk) {
            msg.push(chunk) 
        }).on('end', function() {
            msg2 = JSON.parse(String(msg)) 
            for(i=0; i<msg2.length; i++) { 
                if(i !=0){
                    if(msg2[i].hourly_rate < msg2[i-1].hourly_rate )
                    obj = JSON.parse(msg2[i]) 
                }
                else
                obj = JSON.parse(msg2[i]) 
            }
            response.write('Name = ' + obj.name + ', Skill = ' + obj.skill +', Experience = ' + 
            obj.experience + ', Hourly_rate = ' + obj.hourly_rate + '\n')
            response.end();
        });
    })
    req.end();
})

// Listening to Server
app.listen(port, () => {
 console.log(`Express Server Running on Port ${port}`)
})