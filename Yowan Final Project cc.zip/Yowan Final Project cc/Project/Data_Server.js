// Modules
require('dotenv').config()
const sql = require('mssql');
const express = require('express')

var DbUserName = process.env.DbUsername
var DbUserPassword = process.env.DbUserPassword
var DbName = process.env.DbName
var DbServerName = process.env.DbServerName
var config = {
    user: DbUserName,
    password: DbUserPassword,
    server: DbServerName, 
    database: DbName 
};

const { send } = require('process')
const port = 5000
const app = express()

app.get('/skill', (req, res) => {
    sql.connect(config, function (err) {
        if (err) console.log(err)
        else console.log("CONNECTED TO MS-SQL")
        var request = new sql.Request();
        let query = 'SELECT * FROM CONSULTANTS WHERE SKILL = ' + req.query.skill_name
        request.query(query, function (err, result) {
            if (err) console.log("ERROR: " + err)
            console.log("ROWS RETURNED: " + result.recordset.length)
            res.setHeader('Content-Type', 'text/html')
            var data = [];
            for(let i=0; i<result.recordset.length; i++) {
                console.log(result.recordset[i]);
                data.push(JSON.stringify(result.recordset[i]))
            }
            console.log(data);
            res.json(data)
 })
 })
})

//Listening to the server
app.listen(port, () => {
 console.log(`Express Server Running on Port ${port}`)
})
